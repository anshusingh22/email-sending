# excel-to-json-in-Node.js

## Tutorial 
http://code.ciphertrick.com/2016/06/05/read-excel-files-convert-json-node-js/

##Quick Setup

1) `git clone https://github.com/rahil471/excel-to-json-in-Node.js.git` <br>
2) `cd excel-to-json-in-Node.js` <br>
3) `npm install` <br>
4) `node app.js` <br>
5) In your browser `http://localhost:3000` <br>
6) Upload excel file and see result <br>
